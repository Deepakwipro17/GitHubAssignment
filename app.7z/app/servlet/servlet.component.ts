import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
 
@Component({
  selector: 'app-servlet',
  templateUrl: './servlet.component.html',
  styleUrls: ['./servlet.component.css']
})
export class AngularServletComponent implements OnInit {
title = 'Spring Mvc Angular Tutorial';
myresponse: any;
readonly APP_URL = 'http://localhost:8080';
  constructor(private _http: HttpClient) { 

  }

  ngOnInit() {
  }
  getAllEmployees() {
    this._http.get(this.APP_URL + '/AngularServLetPro/anguServ').subscribe(
      data => {
        console.log('Data Fetched ', data);
        this.myresponse = data;
      },
      error => {
        console.log('Error occured', error);
      }
    );
}
}