import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ServletComponent } from './servlet.component';

describe('ServletComponent', () => {
  let component: ServletComponent;
  let fixture: ComponentFixture<ServletComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ServletComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ServletComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
