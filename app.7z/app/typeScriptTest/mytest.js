var MyTest = /** @class */ (function () {
    function MyTest() {
    }
    return MyTest;
}());
